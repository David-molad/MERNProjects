import React from "react";

import "./Components/styles.css";
import Main from "./Components/Main";

export default function App() {
  return (
    <>
      <Main />
    </>
  );
}
