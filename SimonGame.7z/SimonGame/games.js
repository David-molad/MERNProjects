var buttonColours = ["red","blue","green","yellow"]
var userClickedPattern = []
var gamePattern =[]
var level = 0;
var start= false;

function started(){
  
    $(`h1`).text(`Press A Key to Start`);
    $(document).keydown(function (e) {
      if (!start) {
        $("h1").text(`Level ${level}`); 
        nextSequence();
        start = true;
      }
      
    });
  }
    
started();


function nextSequence(){
  userClickedPattern = []
    $(document).click($(`h1`).text(`Level ${++level} `));
    var randomNumber = Math.floor(Math.random() * 4);
    var randomChosenColour = buttonColours[randomNumber];
    
    gamePattern.push(randomChosenColour);
    $(`#${randomChosenColour}`).fadeIn(100).fadeOut(100).fadeIn(100)
    
}

$(`.btn`).click(function(){
    var userChosenColour = $(this).attr(`id`);
    userClickedPattern.push(userChosenColour);
    playSound(userChosenColour);
    animatePress(userChosenColour);
    checkAnswer(userClickedPattern.length - 1);
   
})

function checkAnswer(currentLevel){
  if(userClickedPattern[currentLevel] === gamePattern[currentLevel]){
    if(userClickedPattern.length === gamePattern.length){
      setTimeout(()=>{
        nextSequence()
      },1000)
      
      //  console.log("sucess")
      // console.log(userClickedPattern);


      userClickedPattern.splice(0,userClickedPattern.length);
    }
    
  }
  else{
    playSound("wrong");
    $(`body`).addClass(`game-over`)
    $(`h1`).html(`Press A Key to Start`);
    setTimeout(() => {
      $(`body`).removeClass(`game-over`)
    },200)
   
    startOver()
    //  console.log("wrong")
    
  }
  console.log(gamePattern);
  console.log(userClickedPattern);
      
}

function playSound(sou){
var audio = new Audio(`sounds/${sou}.mp3`)
return audio.play()

}
function animatePress(currentColour){
  $(`#${currentColour}`).addClass(`pressed`)
    setTimeout(() => {
        $(`#${currentColour}`).removeClass(`pressed`)
    },100)
    

}
function startOver(){
  start = false;
  level = 0;
  gamePattern = []


}



