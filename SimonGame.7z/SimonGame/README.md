# SIMON'S GAME

## About the game

Alaye it is a simple memory game sha where the computer choses one random box for each level and the player has to choose the box that matches the one chosen by the computer from the starting level to your current level.

### For more information [CLICK HERE](https://en.wikipedia.org/wiki/Simon_(game))

### For instructions [CLICK TO WATCH](https://youtu.be/EWJ5uYwQJGU)

## Stack

- HTML
- CSS(bootstrap)
- Javascript(JQuery)

## [Link to the page](https://simon-game-challenge-starting-files.vercel.app/)
